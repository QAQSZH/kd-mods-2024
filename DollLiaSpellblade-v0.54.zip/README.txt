        ^
 _______|\       KD - Spellblade Class v0.54
[///////| >====================----------
        |/               ~By Doll.Lia
        V
					
#=================================#
#              About              #
#=================================#

This mod adds the Spellblade class to Kinky Dungeon.
> Starts with 125 MP, 125 SP, and Vault.
> Starts with Spellweaver, empowering your next melee attack after casting a spell.

Features custom spritework drawn by Doll.Lia.


#=================================#
#              Notes              #
#=================================#

Mod Configuration Menu is included.
 > Has some important toggles if you ever run into mod conflicts.



#========================================#
#====    Potential Mod Conflicts     ====#
#========================================#

KDTestSpellHits() - If another mod overrides this function, disable this feature in the MCM.




#=========================================#
#==             Changelog               ==#
#=========================================#

v0.54:
* LOAD EXISTING SAVE - You will be refunded +1 SP from Fleche, and Vault is removed if you never bought Dodge 1.
* BALANCE PATCH - Fleche requires Spellweaver to use.  After dash-stabbing my way through several levels with a Dagger, this nerf had to happen at a minimum.
* Added this Changelog!
* Spellblade starts the game with Fleche.
* Fleche sprite update.
* Fleche & Displacement show SP/SWVR costs and leg components status. Cost shows 999 if you cannot sprint.
* Fleche & Displacement apply full Thrusting Sword damage.
* Fleche & Displacement now require slow level < 2, or < 3 if you have Deft Footwork.
* Fleche cannot be used to dash through barricades and turrets.
* Fleche loses 1 range if you are slowed.

v0.53:
* BUGFIX - Using the ranged attack of Spears no longer cause a crash log on Spellblade.

v0.52:
* BUGFIX - MCM menu text is now functional on Stable.
* BUGFIX - Blade Twirl is set correctly if you reboot the game with the KDTestSpellHits() override disabled.

v0.51:
* BUGFIX - Blade Twirl blocks projectiles consistently.
* BUGFIX - Blade Twirl no longer blocks ground-targeted AoEs.
* Mod Configuration Menu






#=========================================#
#==  Kinky Dungeon - Spellblade Class   ==#
#==       Credits & Attributions        ==#
#=========================================#


#================================#
#          Doll.Lia              #
#================================#

1.) Spritework
* Most sprites are made using the default Aseprite palette Rosy-42.

2.) Mod Code


NOTE:
* You may use my mod code to write your own mods for Kinky Dungeon.
* You may NOT use my spritework without permission.


#===================================#
#      Strait Laced Games LLC       #
#===================================#

1.) Kinky Dungeon Source Code

2.) Original Kinky Dungeon Sprites & SFX


#=================================#
#        Code Assistance          #
#=================================#

Thank you to the KD Community for being super helpful~

* Ada18980      - Help with enemy attack detection code & sprite nearest neighbor fix.
* Enraa         - MCM base code.


#=================================#
#             Audio               #
#=================================#

DLSE_Twirl.ogg - Rotate Movement Whoosh 1 (Royalty-free)
https://pixabay.com/sound-effects/rotate-movement-whoosh-1-185335/




翻译
        ^
 _______|\       KD - Spellblade Class v0.54
[///////| >====================----------
        |/               ~By Doll.Lia
        V
 
#=================================#
#关于#
#=================================#
此模组将法术刃类添加到奇想地牢。
>从125 MP、125 SP和Vault开始。
>从Spellweaver开始，在施放法术后授权您的下一次近战攻击。
以Doll绘制的自定义精灵为特色。利亚。
#=================================#
#注意事项#
#=================================#
包括Mod配置菜单。
>如果你遇到模组冲突，有一些重要的切换。
#========================================#
#=====潜在的模块冲突====#
#========================================#
KDTestSpellHits（）-如果另一个mod覆盖了此功能，请在MCM中禁用此功能。
#=========================================#
#==变更日志==#
#=========================================#
v0.54：
*加载现有保存-您将从Fleche获得+1 SP的退款，如果您从未购买过Dodge 1，则Vault将被删除。
*平衡补丁-Fleche需要Spellweaver使用。在用匕首刺穿几层楼后，这种神经必须至少发生。
*添加了此更改日志！
*Spellblade以Fleche开始游戏。
*Fleche精灵更新。
*Fleche&Displacement显示SP/SWVR成本和腿部组件状态。如果你不能冲刺，成本显示为999。
*肉搏和置换施加全推搡剑伤害。
*Fleche&Displacement现在需要慢级别<2，如果你有Deft Footwork，则需要<3。
*跳蚤不能用来冲过路障和炮塔。
*如果你减速，跳蚤会失去1个射程。
v0.53：
*BUGFIX-使用Spears的远程攻击不再在Spellblade上造成崩溃日志。
v0.52：
*BUGFIX-MCM菜单文本现在在Stable上可用。
*BUGFIX-如果您在禁用KDTestSpellHits（）覆盖的情况下重新启动游戏，则Blade Twirl设置正确。
v0.51:
*BUGFIX-Blade Twirl始终如一地阻挡投射物。
*BUGFIX-Blade Twirl不再阻挡地面目标AoE。
*Mod配置菜单

#=========================================#
#==怪异地牢-法术类==#
#==学分和归属==#
#=========================================#
#================================#
#娃娃。Lia#
#================================#
1.）喷水作业
*大多数精灵都是使用默认的Aseprite调色板Rosy-42制作的。
2.）型号代码
注：
*你可以使用我的mod代码为Kinky Dungeon编写自己的mod。
*未经许可，您不得使用我的作品。
#===================================#
#海峡花边游戏有限责任公司#
#===================================#
1.）怪异地牢源代码
2.）原始奇趣地牢精灵和SFX
#=================================#
#代码协助#
#=================================#
感谢KD社区的大力帮助~
*Ada18980-帮助敌人攻击检测代码和精灵最近邻修复。
*Enraa-MCM基本代码。
#=================================#
#音频#
#=================================#
DLSE_Tirl.og-嗖嗖旋转运动音频1（免版税）
https://pixabay.com/sound-effects/rotate-movement-whoosh-1-185335/